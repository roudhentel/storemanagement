mainApp.controller("mainCtrl", ($scope) => {
    $scope.toggleRightSidebar = function () {
        if ($('body').hasClass('control-sidebar-open')) {
            $.AdminLTE.controlSidebar.close();
        } else {
            $.AdminLTE.controlSidebar.open();
        }
    }
    
});